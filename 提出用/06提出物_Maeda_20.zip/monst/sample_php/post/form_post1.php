<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>フォーム：POST</title>
</head>
<body>

<form method="post" action="form_post2.php">
<p>お名前:<input type="text" name="name" size="20"></p>
<p>MAIL:<input type="text" name="mail" size="20"></p>
<p><input type="submit" value="送信"></p>
</form>

</body>
</html>
